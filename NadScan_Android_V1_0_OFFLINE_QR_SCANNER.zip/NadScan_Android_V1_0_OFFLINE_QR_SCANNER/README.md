# NadScan Android V1.0

Independent offline QR scanner app using the NadEx visual family.

## App identity
- App name: NadScan
- Package ID: ae.nadscan.app
- Version: 1.0
- Version code: 1

## Features
- Camera QR scanning
- QR decoding locally on the device
- No internet permission
- Copy scanned content
- Share scanned content
- Open HTTP/HTTPS links
- Flashlight control
- Last scan retained locally
- Dedicated in-app back button
- NadEx family artwork and launcher graphic reused as requested

## Privacy
NadScan does not upload scan content. No account, cloud service, or internet permission is required at runtime.
