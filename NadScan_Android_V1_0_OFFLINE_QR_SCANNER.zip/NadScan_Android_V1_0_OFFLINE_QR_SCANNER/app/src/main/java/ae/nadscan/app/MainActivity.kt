package ae.nadscan.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var resultPanel: LinearLayout
    private lateinit var resultText: TextView
    private lateinit var resultType: TextView
    private lateinit var openButton: Button

    private var lastValue: String = ""

    private val scannerLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val value = result.data?.getStringExtra(ScanActivity.EXTRA_RESULT).orEmpty()
                if (value.isNotBlank()) {
                    showResult(value)
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        resultPanel = findViewById(R.id.resultPanel)
        resultText = findViewById(R.id.resultText)
        resultType = findViewById(R.id.resultType)
        openButton = findViewById(R.id.openButton)

        findViewById<Button>(R.id.scanButton).setOnClickListener {
            scannerLauncher.launch(Intent(this, ScanActivity::class.java))
        }

        findViewById<Button>(R.id.copyButton).setOnClickListener {
            if (lastValue.isNotBlank()) {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("NadScan", lastValue))
                Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.shareButton).setOnClickListener {
            if (lastValue.isNotBlank()) {
                startActivity(
                    Intent.createChooser(
                        Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, lastValue)
                        },
                        "Share QR content"
                    )
                )
            }
        }

        openButton.setOnClickListener {
            if (isWebLink(lastValue)) {
                runCatching {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(lastValue)))
                }.onFailure {
                    Toast.makeText(this, "No app can open this link.", Toast.LENGTH_SHORT).show()
                }
            }
        }

        val prefs = getSharedPreferences("nadscan", MODE_PRIVATE)
        prefs.getString("last_scan", null)?.let {
            if (it.isNotBlank()) showResult(it)
        }
    }

    private fun showResult(value: String) {
        lastValue = value
        resultPanel.visibility = android.view.View.VISIBLE
        resultText.text = value

        val isLink = isWebLink(value)
        resultType.text = if (isLink) "WEB LINK" else "TEXT / QR CONTENT"
        openButton.visibility = if (isLink) android.view.View.VISIBLE else android.view.View.GONE

        getSharedPreferences("nadscan", MODE_PRIVATE)
            .edit()
            .putString("last_scan", value)
            .apply()
    }

    private fun isWebLink(value: String): Boolean {
        val s = value.trim().lowercase()
        return s.startsWith("https://") || s.startsWith("http://")
    }
}
