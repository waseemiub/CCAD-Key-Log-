package ae.nadscan.app

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.journeyapps.barcodescanner.BarcodeCallback
import com.journeyapps.barcodescanner.BarcodeResult
import com.journeyapps.barcodescanner.DecoratedBarcodeView

class ScanActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_RESULT = "nadscan_result"
    }

    private lateinit var scanner: DecoratedBarcodeView
    private var torchOn = false
    private var completed = false

    private val callback = object : BarcodeCallback {
        override fun barcodeResult(result: BarcodeResult?) {
            val value = result?.text.orEmpty()
            if (value.isBlank() || completed) return
            completed = true
            scanner.pause()
            setResult(
                RESULT_OK,
                Intent().putExtra(EXTRA_RESULT, value)
            )
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scan)

        scanner = findViewById(R.id.barcodeScanner)
        scanner.decodeContinuous(callback)

        findViewById<Button>(R.id.backButton).setOnClickListener {
            finish()
        }

        findViewById<Button>(R.id.torchButton).setOnClickListener {
            torchOn = !torchOn
            if (torchOn) scanner.setTorchOn() else scanner.setTorchOff()
            it as Button
            it.text = if (torchOn) "LIGHT ON" else "LIGHT"
        }
    }

    override fun onResume() {
        super.onResume()
        completed = false
        scanner.resume()
    }

    override fun onPause() {
        scanner.pause()
        super.onPause()
    }
}
