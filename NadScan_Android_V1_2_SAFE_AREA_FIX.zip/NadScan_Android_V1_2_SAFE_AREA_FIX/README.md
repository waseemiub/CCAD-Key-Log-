# NadScan Android V1.2

Independent offline QR scanner using the NadEx visual family.

## V1.2
- Dedicated NadScan launcher icon
- Runtime camera permission and scanner opening fix
- Android safe-area handling added
- Content stays below the phone status/camera area
- Content stays above the Android bottom navigation/gesture bar
- Existing offline QR scan, flashlight, copy, share, open-link and local last-scan behavior retained

## Identity
- App name: NadScan
- Package ID: ae.nadscan.app
- Version: 1.2
- Version code: 3
