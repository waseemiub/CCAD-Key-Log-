package ae.nadscan.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.Insets
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.content.ContextCompat
import com.journeyapps.barcodescanner.BarcodeCallback
import com.journeyapps.barcodescanner.BarcodeResult
import com.journeyapps.barcodescanner.DecoratedBarcodeView

class ScanActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_RESULT = "nadscan_result"
    }

    private lateinit var scanner: DecoratedBarcodeView
    private var torchOn = false
    private var completed = false
    private var cameraReady = false

    private val cameraPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                startCamera()
            } else {
                Toast.makeText(
                    this,
                    "Camera permission is required to scan QR codes.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

    private val callback = object : BarcodeCallback {
        override fun barcodeResult(result: BarcodeResult?) {
            val value = result?.text.orEmpty()
            if (value.isBlank() || completed) return

            completed = true
            scanner.pause()

            setResult(
                RESULT_OK,
                Intent().putExtra(EXTRA_RESULT, value)
            )
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scan)

ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content)) { view, insets ->
    val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
    view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
    insets
}


        scanner = findViewById(R.id.barcodeScanner)
        scanner.decodeContinuous(callback)

        findViewById<Button>(R.id.backButton).setOnClickListener {
            finish()
        }

        findViewById<Button>(R.id.torchButton).setOnClickListener {
            if (!cameraReady) {
                requestCameraIfNeeded()
                return@setOnClickListener
            }

            torchOn = !torchOn
            if (torchOn) scanner.setTorchOn() else scanner.setTorchOff()

            (it as Button).text = if (torchOn) "LIGHT ON" else "LIGHT"
        }

        requestCameraIfNeeded()
    }

    private fun requestCameraIfNeeded() {
        when {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED -> {
                startCamera()
            }

            else -> {
                cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
            }
        }
    }

    private fun startCamera() {
        cameraReady = true
        completed = false
        scanner.resume()
    }

    override fun onResume() {
        super.onResume()

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            startCamera()
        }
    }

    override fun onPause() {
        if (::scanner.isInitialized) {
            scanner.pause()
        }
        super.onPause()
    }
}
